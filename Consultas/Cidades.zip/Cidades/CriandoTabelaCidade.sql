CREATE TABLE cidade(
					id_cidade NUMERIC PRIMARY KEY,	
					nome VARCHAR(30),
					rua VARCHAR(30),
					cidade VARCHAR(30),
					estado VARCHAR(30)
                   );