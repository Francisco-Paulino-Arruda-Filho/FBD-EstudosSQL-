-- Inserir algumas cidades brasileiras na tabela "cidade"
INSERT INTO cidade (id_cidade, nome, rua, cidade, estado) VALUES
(1, 'São Paulo', 'Avenida Paulista', 'São Paulo', 'SP'),
(2, 'Rio de Janeiro', 'Copacabana', 'Rio de Janeiro', 'RJ'),
(3, 'Belo Horizonte', 'Rua da Bahia', 'Belo Horizonte', 'MG'),
(4, 'Salvador', 'Pelourinho', 'Salvador', 'BA'),
(5, 'Recife', 'Boa Viagem', 'Recife', 'PE'),
(6, 'Fortaleza', 'Praia de Iracema', 'Fortaleza', 'CE'),
(7, 'Porto Alegre', 'Moinhos de Vento', 'Porto Alegre', 'RS'),
(8, 'Brasília', 'Esplanada dos Ministérios', 'Brasília', 'DF'),
(9, 'Curitiba', 'Rua XV de Novembro', 'Curitiba', 'PR'),
(10, 'Manaus', 'Centro', 'Manaus', 'AM');
